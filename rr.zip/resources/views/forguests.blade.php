@include('header')

    <h1>please autorize for see this page</h1>
</body>
